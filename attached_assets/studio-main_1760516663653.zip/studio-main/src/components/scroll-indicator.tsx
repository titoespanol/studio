"use client";

export function ScrollIndicator() {
  return (
    <div className="flex flex-col items-center">
      <div className="mouse" />
    </div>
  );
}
